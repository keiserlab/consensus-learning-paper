/* mac os x libtool needs to link libraries containing c++ (eg. cimg) with 
 * g++ ... force this with a dummy c++ file at the top level
 */
const int im__dummy_value = 42;
